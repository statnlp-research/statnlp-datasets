A multilingual dataset for Geoquery.
Each instance is a sentence annotated annotated with its meaning representations.
The corpora in Chinese, Indonesia, Farsi and Swedish are originally released by “Semantic Parsing with Neural Hybrid Trees”.