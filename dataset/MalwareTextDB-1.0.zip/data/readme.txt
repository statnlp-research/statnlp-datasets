=====================
MALWARETEXTDB DATASET
=====================

This folder contains the datasets that constitute MalwareTextDB.

ann+brown/
- contains the tokenized reports with POS tags from Stanford's POSTagger and incorporating the annotations in BIO format with additional features from Brown clustering

annotations/ 
- contains the plaintext files with XML tags denoting nonsentence sections such as headings and covers
- contains the annotations files (.ann) for each plaintext file; the positions of the annotations are based on character counts 

brown_ext_training_set/
- contains the plaintext files of reports NOT in annotated database but used as part of training set for Brown clustering

plaintext/ 
- contains the plaintext files after the PDF reports are processed with PDFMiner

signatures/
- contains the list of malware signatures detected for each APT report

tokenized/
- contains the tokenized reports with POS tags from Stanford's POSTagger and incorporating the annotations in BIO format