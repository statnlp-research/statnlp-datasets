===========================
MALWARETEXTDB SUPPLEMENTARY
===========================

This folder contains the supplementary material for MalwareTextDB.

AnnotationGuidelines_V2.00.pdf
- contains annotation guidelines with examples for annotating token, relation and attribute labels

AttributeLabels_V1.01.pdf
- contains a list of attribute labels extracted from the MAEC vocabulary
- contains a list relevant word-phrases for each attribute label