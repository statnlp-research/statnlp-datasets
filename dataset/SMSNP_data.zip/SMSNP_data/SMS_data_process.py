#!/usr/bin/python2
# coding=utf-8

##===================================================================##
#   Turn the annotated SMS data into label format
#   Jie Yang
#   Nov. 4, 2015
#   
#   EDIT by Aldrian Obaja
#   Change to output spans instead of tokenized version
#   The tokenized version can be accessed by giving argument "1"
#   e.g., python2 SMS_data_process.py 1
#   Note that this script requires Python 2, it does not run in Python 3
#   Note also that although this was kept to produce the same
#   tokenization with the Java version, this tokenizer is eventually
#   not used
# 
##===================================================================##
import sys
import os
import types
import re
import random

def get_sentence_list(txt_list, use_windows_endline=False):
    sent_end = 1
    sent_list = []
    for sentence in txt_list:
        sent_pair = []
        sent_pair.append(sent_end)
        sent_pair.append(sentence.decode('utf-8'))
        sent_list.append(sent_pair)
        sent_end += len(sentence.decode('utf-8')) 
        if use_windows_endline:
            sent_end += 1
    return sent_list    

def list_clean(input_list):
    output_list = []
    sent = ''
    if len(input_list) < 1:
        print 'error'
        return 0
    else:
        output_list.append(input_list[0])
        for idx in range(1, len(input_list)):
            if idx != len(input_list) -1:
                sent += input_list[idx].encode('utf-8')
            else:
                sent += input_list[idx].encode('utf-8')
    return sent

def get_sentence_position(input_list):
    position_list = []
    for sentence, spans in input_list:
        if len(sentence) < 2:
            continue
        words = sentence.split(' ')
        if  words[0].find('#[') >= 0:
            continue
        position_list.append(int(words[0]))
    return set(position_list)

def sort_ann(ann_list):
    result = []
    for ann_label in ann_list:
        line_ann_list = ann_label.split('\t')
        if len(line_ann_list) != 3:
            print 'ann file error type 1! {}'.format(ann_label)
            continue
        np_pair = line_ann_list[1].split(' ')
        if len(np_pair) < 3:
            print 'ann file error type 2! {}'.format(line_ann_list[1])
            continue
        np_pair[1] = int(np_pair[1])
        np_pair[2] = int(np_pair[2])
        result.append((np_pair[1], np_pair[2], line_ann_list[2]))
    result.sort(key=lambda x: x[0])
    tmp = result[:]
    result = []
    prev_ann = None
    for ann in tmp:
        if prev_ann is not None:
            if prev_ann[1] > ann[0]:
                if prev_ann[1] - prev_ann[0] >= ann[1] - ann[0]:
                    print 'Ignoring {}, overlap with {}'.format(ann, prev_ann)
                else:
                    result[-1] = ann
                    print 'Ignoring {}, overlap with {}'.format(prev_ann, ann)
                    prev_ann = ann
                continue
        result.append(ann)
        prev_ann = ann
    return result

def label_extract(ann_input, txt_input):
    print 'begin extract file: ', ann_input
    ann_list = open(ann_input, 'rU').readlines()
    txt_list = open(txt_input, 'rU').readlines()
    use_windows_endline = False
    if '46/' in txt_input:
        txt = open(txt_input, 'rU').read()
        txt = txt[:8195] + txt[8195:].replace('\n', '\r\n')
        txt_list = txt.split('\n')
        txt_list = [text+'\n' for text in txt_list if text != '']
    if '53/' in txt_input:
        use_windows_endline = True
    sent_list = get_sentence_list(txt_list, use_windows_endline)
    len_sent_list = len(sent_list)
    new_sent_list = []
    temp_list = []
    last_line_number = 0
    last_line_sent = ''
    last_end = 0
    last_np_pair_begin = 0
    ann_list = sort_ann(ann_list)
    prev_idx = 0
    spans = []
    for ann_label in ann_list:
        np_pair = ('Noun-Phrase', ann_label[0], ann_label[1])

        for idx in range(prev_idx, len_sent_list):
            sent_list[idx][0] = int(sent_list[idx][0])
            # print sent_list[idx]
            if  np_pair[1] <= sent_list[idx][0]:
                if last_line_number != sent_list[idx][0]:  # This annotation is in new sentence, put previous sentence in the annotated list
                    temp_list.append(last_line_sent[last_end:])
                    if temp_list != []:
                        new_sent_list.append((list_clean(temp_list), spans))
                    spans = []
                    temp_list = []
                    temp_list.append(int(sent_list[idx-1][0]))
                    np_start = np_pair[1]-int(sent_list[idx-1][0]) + 1
                    np_end = np_pair[2]-int(sent_list[idx-1][0]) +1
                    spans.append((np_start, np_end, 'NP'))
                    last_line_sent = sent_list[idx-1][1]
                    annotated_text = last_line_sent[np_start:np_end]
                    if annotated_text == '':
                        print 'np_start: {}, np_end: {}, start_idx: {}, sent: {}'.format(np_start, np_end, sent_list[idx][0], last_line_sent)
                    if annotated_text[-1] == ' ':
                        print 'Ends with space: np_pair[1]:{}, np_pair[2]:{}, text:{}, sent:{}'.format(np_pair[1], np_pair[2], annotated_text, last_line_sent)
                    temp_list.append(last_line_sent[0:np_start] + '#[' + last_line_sent[np_start:np_end] + ']#')
                    last_line_number = sent_list[idx][0]
                    last_end = np_end
                    # print temp_list
                    prev_idx = idx
                    break
                else:  # This annotation is in the same sentence as previous one, add to temporary list
                    np_start = np_pair[1]-int(sent_list[idx-1][0]) + 1
                    np_end = np_pair[2]-int(sent_list[idx-1][0]) +1
                    spans.append((np_start, np_end, 'NP'))
                    last_line_sent = sent_list[idx-1][1]
                    temp_list.append(last_line_sent[last_end:np_start] + '#[' + last_line_sent[np_start:np_end] + ']#')
                    annotated_text = last_line_sent[np_start:np_end]
                    if annotated_text == '':
                        print 'np_start: {}, np_end: {}, start_idx: {}, sent: {}'.format(np_start, np_end, sent_list[idx][0], last_line_sent)
                    if annotated_text[-1] == ' ':
                        print 'Ends with space: np_pair[1]:{}, np_pair[2]:{}, text:{}, sent:{}'.format(np_pair[1], np_pair[2], annotated_text, last_line_sent)
                    last_line_number = sent_list[idx][0]
                    last_end = np_end
                    # print temp_list
                    prev_idx = idx
                    break
            else:
                prev_idx = idx
                continue
    labeled_position = get_sentence_position(new_sent_list)

    for full_sentence in sent_list:
        full_position = int(full_sentence[1].split(' ')[0])
        if full_position in labeled_position:
            continue
        else:
            new_sent_list.append((full_sentence[1].encode('utf-8'), []))

    # post process list, delete null elements
    annotated_list = []
    for pairs, spans in new_sent_list:
        if len(pairs) < 2:
            continue
        annotated_list.append((pairs, spans))
    return annotated_list

def sentence_list_combine(old_sentence_list, add_sentence_list):
    old_positions = get_sentence_position(old_sentence_list)
    for sentence, spans in add_sentence_list:
        if  sentence.split(' ')[0].find('#[') >= 0:
            continue
        add_sent_position = int(sentence.split(' ')[0])
        if add_sent_position in old_positions:
            # print add_sent_position
            continue
        else:
            old_sentence_list.append((sentence, spans))
    return old_sentence_list

from nltk import wordpunct_tokenize

def tokenize(sentence): # Although this was kept to produce the same tokenization with the Java version, this tokenizer is eventually not used
    tokens = wordpunct_tokenize(sentence)
    result = []
    prev_token = ''
    last_found = 0
    for token in tokens:
        while True:
            try:
                start_delim_idx = token.find('#[')
                end_delim_idx = token.find(']#')
                if 0 <= start_delim_idx and (end_delim_idx == -1 or start_delim_idx < end_delim_idx):
                    bef_delim = token[:start_delim_idx]
                    if bef_delim != '':
                        result.append(bef_delim)
                    if end_delim_idx != -1:
                        result.append(token[start_delim_idx:end_delim_idx+2])
                        token = token[end_delim_idx+2:]
                        continue
                    else:
                        if len(token[start_delim_idx:]) != 2:
                            result.append(token[start_delim_idx:])
                        else:
                            prev_token = token[start_delim_idx:]
                    break
                elif 0 <= end_delim_idx and (start_delim_idx == -1 or end_delim_idx < start_delim_idx):
                    if end_delim_idx == 0:
                        result[-1] = result[-1]+token[:end_delim_idx+2]
                    else:
                        result.append(token[:end_delim_idx+2])
                    aft_delim = token[end_delim_idx+2:]
                    if aft_delim != '':
                        token = aft_delim
                        continue
                    else:
                        break
                else:
                    if len(result) > 0 and result[-1].endswith("'") and re.match('([dDsSmMtT]|ll|LL|ve|VE|re|RE).*', token) and (sentence.find("'"+token, last_found+1) != -1):
                        last_found = sentence.find("'"+token, last_found+1)-1
                        result[-1] = result[-1] + token
                    else:
                        result.append(prev_token+token)
                        prev_token = ''
                    if len(result) > 0 and (result[-1] == "'t" or result[-1] == "'T"):
                        if (result[-2].endswith('n') or result[-2].endswith('N')) and (sentence.find(result[-2][-1]+result[-1], last_found) != -1):
                            last_found = sentence.find(result[-2][-1]+result[-1], last_found)
                            result[-1] = result[-2][-1] + result[-1]
                            result[-2] = result[-2][:-1]
                    break
            finally:
                if re.match(r'^([\'`"][,\.?!]|[,\.?!][\'`"]).*', result[-1]):
                    result.append(result[-1][1:])
                    result[-2] = result[-2][:1]
    tmp = result[:]
    result = []
    for token in tmp:
        result.append(token)
        if len(result) >= 2 and result[-2].endswith('<') and re.match('.*(#\\[)?(DECIMAL|URL|EMAIL|TIME|DATE|IP|name)(\\]#)?', result[-1]):
            if result[-1].startswith('[#'):
                result[-2] = '[#' + result[-2] + result[-1][2:]
            else:
                result[-2] = result[-2] + result[-1]
            result[-1:] = []
        if len(result) >= 2 and re.match('.*(#\\[)?<(DECIMAL|URL|EMAIL|TIME|DATE|IP|name)$', result[-2]) and result[-1].startswith('>'):
            if result[-2].endswith(']#'):
                result[-2] = result[-2][:-2] + result[-1] + ']#'
            else:
                result[-2] = result[-2] + result[-1]
            result[-1:] = []
    tmp = result[:]
    result = []
    last_end = 0
    for token in tmp:
        if len(result) > 0 and sentence.find(token, last_end) == last_end and (result[-1].endswith(']#') or token.startswith('#[')):
            result[-1] += token
        else:
            result.append(token)
        last_end = sentence.find(token, last_end) + len(token)
    return result

TAG_OUTSIDE_BEFORE = 'O-B'
TAG_OUTSIDE_INSIDE = 'O-I'
TAG_OUTSIDE_AFTER = 'O-A'
TAG_OUTSIDE = 'O'
TAG_NP_START = 'B-NP'
TAG_NP_INSIDE = 'I-NP'

USE_SINGLE_OUTSIDE_TAG = False
if USE_SINGLE_OUTSIDE_TAG:
    TAG_OUTSIDE_BEFORE = 'O'
    TAG_OUTSIDE_INSIDE = 'O'
    TAG_OUTSIDE_AFTER = 'O'

def sentence_list_to_file(sentence_list, output_file, is_conll=True):
    outfile = open(output_file, 'w')
    if is_conll:
        for sentence, spans in sentence_list:
            sentence = sentence.decode('utf-8')
            words = tokenize(sentence)
            # words = sentence.split(' ')
            words = [word.encode('utf-8') for word in words]
            words_num = len(words)
            begin_flag = False
            special_space = False
            for idx in range(1, words_num):
                if (words[idx] == '\n') or (len(words[idx])<1):
                    continue
                if words[idx].find("\n") >= 0:
                    words[idx] = words[idx].split('\n')[0]
                
                cur_token = words[idx]
                first_time = True  # A flag to indicate whether the cur_token is original or after some splitting
                while len(cur_token) > 0:
                    cur_token = cur_token.strip()
                    start_tag_idx = cur_token.find("#[")
                    end_tag_idx = cur_token.find("]#")
                    if 0 <= start_tag_idx and (end_tag_idx < 0 or start_tag_idx < end_tag_idx):
                        before, word = re.split(r'#\[', cur_token, maxsplit=1)
                        if before != '':
                            if first_time:
                                outfile.write('{} {}\n'.format(before, TAG_OUTSIDE_BEFORE))
                            else:
                                outfile.write('{} {}\n'.format(before, TAG_OUTSIDE_INSIDE))
                        begin_flag = True
                        if word.find("]#") >= 0:
                            word, cur_token = re.split(r']#', word, maxsplit=1)
                            begin_flag =False
                        else:
                            cur_token = ''
                        if word == '':
                            print words[idx-1:idx+3]
                            word = '*tag-error*'
                        outfile.write('{} {}\n'.format(word, TAG_NP_START))
                    elif 0 <= end_tag_idx and (start_tag_idx < 0 or end_tag_idx < start_tag_idx):
                        begin_flag = False
                        word, cur_token = re.split(r']#', cur_token, maxsplit=1)
                        if word == '':
                            print words[idx-1:idx+3]
                            word = '*tag-error*'
                        outfile.write('{} {}\n'.format(word, TAG_NP_INSIDE))
                    else:
                        if begin_flag:
                            word = cur_token
                            if word == '':
                                print words[idx-1:idx+3]
                                word = '*tag-error*'
                            outfile.write('{} {}\n'.format(word, TAG_NP_INSIDE))
                            cur_token = ''
                        else:
                            word = cur_token
                            if word == '':
                                print words[idx-1:idx+3]
                                word = '*tag-error*'
                            if first_time:
                                outfile.write('{} {}\n'.format(word, TAG_OUTSIDE))
                            else:
                                outfile.write('{} {}\n'.format(word, TAG_OUTSIDE_AFTER))
                            cur_token = ''
                    first_time = False
            outfile.write('\n')
    else:
        for sentence, spans in sentence_list:
            space = sentence.find(' ')
            clean_sentence = sentence.replace('#[', '').replace(']#', '')[space+1:].strip('\r\n')
            spans = ['{},{} {}'.format(start-space-1, end-space-1, label) for start, end, label in spans]
            outfile.write('{}\n{}\n'.format(clean_sentence, '|'.join(spans)))
            outfile.write('\n')

    outfile.close()
    return 1

if __name__ == '__main__':
    is_conll = False
    if len(sys.argv) > 1:
        is_conll = int(sys.argv[1]) == 1
    current_path = os.path.dirname(__file__)
    if is_conll:
        train_file = 'SMSNP.conll.train'
        dev_file = 'SMSNP.conll.dev'
        test_file = 'SMSNP.conll.test'
    else:
        train_file = 'SMSNP.train'
        dev_file = 'SMSNP.dev'
        test_file = 'SMSNP.test'
    father_path = os.path.join(current_path, 'sms_corpus/students/')
    ann_child_path = 'sms_corpus.ann'
    txt_child_path = 'sms_corpus.txt'
    for root, dirs, files in os.walk(father_path):
        folder_list = dirs
        break
    full_sentence_list = []
    excluded_students = set(['36', # Bad annotation
                             '50', # No annotation
                             '63', # No annotation
                             ])
    for folder in folder_list:
        if folder in excluded_students:
            continue
        input_folder = os.path.join(father_path,folder)
        input_ann_file = os.path.join(input_folder,ann_child_path)
        input_txt_file = os.path.join(input_folder,txt_child_path)
        annotated_list = label_extract(input_ann_file, input_txt_file)
        sentence_list_combine(full_sentence_list, annotated_list)
    random.seed(10)
    random.shuffle(full_sentence_list)

    whole_sentence_number = len(full_sentence_list)

    train_rate = 0.8
    dev_rate = 0.1
    test_rate = 0.1
    
    train_part = int(train_rate/(train_rate+dev_rate + test_rate)* whole_sentence_number)
    dev_part = int(dev_rate/(train_rate+dev_rate + test_rate)* whole_sentence_number)
    test_part = int(test_rate/(train_rate+dev_rate + test_rate)* whole_sentence_number)
    sentence_list_to_file(full_sentence_list[0:train_part], train_file, is_conll=is_conll)
    sentence_list_to_file(full_sentence_list[train_part:train_part+dev_part], dev_file, is_conll=is_conll)
    sentence_list_to_file(full_sentence_list[train_part+dev_part:train_part+dev_part+test_part], test_file, is_conll=is_conll)

    print 'Whole corpus sentence number: ', whole_sentence_number
    print 'Train corpus sentence number: ', train_part
    print 'Dev corpus sentence number: ', dev_part
    print 'Test corpus sentence number: ', test_part
    print 'data extraction finished'


